package com.practica.controller.dao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.google.gson.Gson;
import com.practicaArreglos.controller.dao.implement.AdapterDao;
import com.practicaArreglos.models.HistorialCrud;
import com.practicaArreglos.models.TipoDeCrud;

public class HistorialCrudDao extends AdapterDao<HistorialCrud> {
    private HistorialCrud historialCrud;
    private HistorialCrud[] listAll; 

    public HistorialCrudDao() {
        super(HistorialCrud.class);
    }
    
    public HistorialCrud getHistorialCrud() {
        if (historialCrud == null) {
            historialCrud = new HistorialCrud();
        }
        return this.historialCrud;
    }

    public void setHistorialCrud(HistorialCrud historialCrud) {
        this.historialCrud = historialCrud;
    }

    public HistorialCrud[] getAllHistorialCrud() throws Exception{
        return listAll();
    }

    public boolean save() throws Exception {
        if (historialCrud == null) {
            throw new Exception("No hay datos para guardar");
        }
        int id = listAll().length + 1; 
        historialCrud.setId(id);
        persist(historialCrud);
        this.historialCrud = null;
        return true;
    }

    public boolean registraHistorial(TipoDeCrud tipoDeCrud, String mensaje) throws Exception {
        String horaFecha = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        HistorialCrud evento = new HistorialCrud(tipoDeCrud, horaFecha, mensaje);
        setHistorialCrud(evento);
        return save();
    }

    public String toJson() throws Exception {
        return g.toJson(this.historialCrud);
    }

    public HistorialCrud getHistorialCrudById(Integer id) throws Exception {
        if (id < 1 || id > listAll().length) {
            throw new Exception("Elemento no encontrado");
        }
        return listAll[id - 1]; 
    }

    public String getHistorialCrudJsonById(Integer id) throws Exception {
        return g.toJson(getHistorialCrudById(id));
    }

    public HistorialCrud[] getListAll() throws Exception{
        return getAllHistorialCrud();
    }

    public void setListAll(HistorialCrud[] listAll) {
        this.listAll = listAll;
    }    

    public TipoDeCrud getTipoDeEventoCrud(String tipoDeEventoCrud) {
        return TipoDeCrud.valueOf(tipoDeEventoCrud);
    }

    public TipoDeCrud[] getTipoDeEventoCrud() {
        return TipoDeCrud.values();
    }
}
