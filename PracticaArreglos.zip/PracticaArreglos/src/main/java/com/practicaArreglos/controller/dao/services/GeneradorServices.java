package com.practicaArreglos.controller.dao.services;

import com.practicaArreglos.controller.dao.GeneradorDao;
import com.practicaArreglos.models.Generador;
import com.practicaArreglos.models.Uso;

public class GeneradorServices {
    private GeneradorDao obj;
    public GeneradorServices(){
        this.obj = new GeneradorDao();
    }

    public Boolean save()throws Exception{
        return obj.save();
    }

    public Generador[] listAll()throws Exception{
        return obj.getListAll();
    }

    public Generador getGenerador(){
        return obj.getGenerador();
    }

    public void setGenerador(Generador generador){
        obj.setGenerador(generador);
    }

    public String toJson(){
        return obj.toJson();
    }  

    public String getAllGeneradorToJson()throws Exception{
        return obj.getAllGeneradorJson();
    }

    public Generador getGeneradorByIndex(Integer index)throws Exception{
        return obj.getGeneradorByIndex(index);
    }

    public String getGeneradorJsonByIndex(Integer index)throws Exception{
        return obj.getGeneradorJsonByIndex(index);
    }

    public void update(Integer index, Generador generador)throws Exception{
        obj.update(index, generador);
    }

    public Boolean deleteGeneradorByIndex(Integer index) throws Exception {
        return obj.deleteGeneradorByIndex(index);
    }

    public Uso getUso(String uso){
        return Uso.valueOf(uso);
    }
    public Uso[] getUso(){
        return Uso.values();
    }
}
