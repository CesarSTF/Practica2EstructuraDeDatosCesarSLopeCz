package com.practicaArreglos.models;

public class Generador {
    private Integer idGenerador;
    private String modelo;
    private float costo;
    private float consumoComustible;
    private float energiaGenerada;
    private Uso uso;

    public Generador(){}

    public Generador(Integer idGenerador, String modelo, float costo, float consumoComustible, float energiaGenerada, Uso uso){
        this.idGenerador = idGenerador;
        this.modelo = modelo;
        this.costo = costo;
        this.consumoComustible = consumoComustible;
        this.energiaGenerada = energiaGenerada;
        this.uso = uso;
    }

    public String getModelo() {
        return this.modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public Uso getUso() {
        return uso;
    }

    public void setUso(Uso uso) {
        this.uso = uso;
    }

    public Integer getIdGenerador() {
        return this.idGenerador;
    }

    public void setIdGenerador(Integer idGenerador) {
        this.idGenerador = idGenerador;
    }

    public float getCosto() {
        return this.costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public float getConsumoComustible() {
        return this.consumoComustible;
    }

    public void setConsumoComustible(float consumoComustible) {
        this.consumoComustible = consumoComustible;
    }

    public float getenergiaGenerada() {
        return this.energiaGenerada;
    }

    public void setenergiaGenerada(float energiaGenerada) {
        this.energiaGenerada = energiaGenerada;
    }

    @Override
    public String toString() {
    return "Generador{" +
            "idGenerador=" + idGenerador +
            ", modelo=" + modelo +
            ", costo=" + costo +
            ", consumoComustible=" + consumoComustible +
            ", energiaGenerada=" + energiaGenerada +
            ", uso=" + (uso != null ? uso.getName() : "No especificado") + 
            '}';
    }
}
