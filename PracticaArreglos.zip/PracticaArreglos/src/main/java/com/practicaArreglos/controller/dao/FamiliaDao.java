package com.practicaArreglos.controller.dao;

import com.google.gson.Gson;
import com.practicaArreglos.controller.dao.implement.AdapterDao;
import com.practicaArreglos.models.Familia;

public class FamiliaDao extends AdapterDao<Familia> {
    private Familia familia;
    private Gson g = new Gson();

    public FamiliaDao() {
        super(Familia.class);
    }

    public Familia getFamilia() {
        if (familia == null) {
            familia = new Familia();
        }
        return familia;
    }

    public void setFamilia(Familia familia) {
        this.familia = familia;
    }

    public Familia[] getListAll() throws Exception {
        return listAll();
    }

    public Boolean save() throws Exception {
        Familia[] currentList = getListAll();
        int nuevoId = 1;
        for (Familia item : currentList) {
            if (item != null && item.getIdFamilias() >= nuevoId) {
                nuevoId = item.getIdFamilias() + 1;
            }
        }
        getFamilia().setIdFamilias(nuevoId);
        this.persist(this.familia);
        return true;
    }

    public String toJson() {
        return g.toJson(getFamilia());
    }

    public String getAllFamiliasJson() throws Exception {
        Familia[] familias = getListAll();
        return g.toJson(familias);
    }

    public Familia getFamiliaByIndex(Integer index) throws Exception {
        return get(index);
    }

    public String getFamiliaJsonByIndex(Integer index) throws Exception {
        return g.toJson(getFamiliaByIndex(index));
    }

    public void update(Integer index, Familia familia) throws Exception {
        super.update(index, familia);
    }

    public Boolean deleteFamiliaByIndex(Integer index) throws Exception {
        this.delete(index);
        Familia[] updateList = listAll();
        for (int i = 0; i < updateList.length; i++) {
            if (updateList[i] != null) {
                updateList[i].setIdFamilias(i + 1);
            }
        }
        saveFile(g.toJson(updateList));
        return true;
    }
}
