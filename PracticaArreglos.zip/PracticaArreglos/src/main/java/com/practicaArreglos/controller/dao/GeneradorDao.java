package com.practicaArreglos.controller.dao;

import com.google.gson.Gson;
import com.practicaArreglos.controller.dao.implement.AdapterDao;
import com.practicaArreglos.models.Generador;
import com.practicaArreglos.models.Uso;


public class GeneradorDao extends AdapterDao<Generador>{
    private Generador generador;
    private Gson g = new Gson();

    public GeneradorDao(){
        super(Generador.class);
    }

    public Generador getGenerador() {
        if (generador == null) {
            generador = new Generador();
        }
        return generador;
    }

    public void setGenerador(Generador generador) {
        this.generador = generador;
    }

    public Generador[] getListAll()throws Exception{
        return listAll();
    }

    public Boolean save() throws Exception {
        Generador[] existingGeneradores = getListAll();
        Integer newId = 1;
    
        for (Generador g : existingGeneradores) {
            if (g != null && g.getIdGenerador() >= newId) {
                newId = g.getIdGenerador() + 1;
            }
        }
    
        getGenerador().setIdGenerador(newId);
        this.persist(getGenerador());
        return true; 
    }
    
    public String toJson(){
        return g.toJson(getGenerador());
    }

    public String getAllGeneradorJson()throws Exception{
        Generador[] generadores = getListAll();
        return g.toJson(generadores);
    }

    public Generador getGeneradorByIndex(Integer index)throws Exception{
        return get(index);
    }

    public String getGeneradorJsonByIndex(Integer index)throws Exception{
        return g.toJson(getGeneradorByIndex(index));
    }

    public void update(Integer index, Generador generador)throws Exception{
        super.update(index, generador);
    }

    public Boolean deleteGeneradorByIndex(Integer index) throws Exception {
        this.delete(index);
        Generador[] updateList = listAll();
        for (int i = 0; i < updateList.length; i++) {
            if (updateList[i] != null) {
                updateList[i].setIdGenerador(i + 1);
            }
        }
        saveFile(g.toJson(updateList));
        return true;
    }

    public Uso getUso(String uso){
        return Uso.valueOf(uso);
    }

    public Uso[] getUso(){
        return Uso.values();
    }
}
