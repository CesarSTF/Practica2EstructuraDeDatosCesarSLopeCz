package com.practicaArreglos.controller.dao.implement;

public interface InterfazDao<T> {
    public void persist(T object) throws Exception;
    public void merge(Integer index, T object) throws Exception;
    public T[] listAll() throws Exception;  
    public T get(Integer id) throws Exception;
    public void delete(Integer index) throws Exception;
    public void update(Integer index, T object) throws Exception;
}
