package com.practicaArreglos.controller.dao.implement;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.Scanner;

import com.google.gson.Gson;

public class AdapterDao<T> implements InterfazDao<T> {
    private Class<T> clazz;
    protected Gson g;
    public String URL = "media/";
    private static final int INITIAL_CAPACITY = 0; 

    public AdapterDao(Class<T> clazz) {
        this.clazz = clazz; 
        this.g = new Gson();
    }

    @Override
    public void persist(T object) throws Exception {
        try {
            T[] array = listAll();
            T[] newArray = (T[]) Array.newInstance(clazz, array.length + 1);
            System.arraycopy(array, 0, newArray, 0, array.length);
            newArray[array.length] = object;

            String info = g.toJson(newArray);
            saveFile(info);
        } catch (Exception e) {
            throw new Exception("Error al persistir el objeto: " + e.getMessage(), e);
        }
    }        

    public void merge(Integer index, T object) throws Exception {
        int indexAjustado = index -1;
        T[] list = listAll();
        if (indexAjustado < 0 || indexAjustado >= list.length || list[indexAjustado] == null) {
            throw new Exception("Indice fuera de rango o elemento no existente");
        }
        list[indexAjustado] = object;

        String info;
        try {
            info = g.toJson(list);
        } catch (Exception e) {
            throw new Exception("Error al convertir a JSON");
        }
        saveFile(info);
    }

    public T[] listAll() throws Exception {
        T[] list;
        try {
            String data = readFile();
            if (data == null || data.equals("[]")) {  
                list = (T[]) Array.newInstance(clazz, INITIAL_CAPACITY);
            } else {
                Type arrayType = Array.newInstance(clazz, 0).getClass();
                list = g.fromJson(data, arrayType);
                if (list == null) {
                    list = (T[]) Array.newInstance(clazz, INITIAL_CAPACITY);
                }
            }
        } catch (Exception e) {
            throw new Exception("Error al convertir a JSON");
        }
        return list;
    }
    
    public T get(Integer id) throws Exception {
        int index = id - 1;
        T[] list = listAll();
        if (id <=  0 || index >= list.length || list[index] == null) {
            throw new Exception("Elemento no encontrado");
        }
        return list[index];
    }

    private String readFile() throws Exception {
        File file = new File(URL + clazz.getSimpleName() + ".json");
        if (!file.exists()) {
            return "[]";
        }

        Scanner in = new Scanner(new FileReader(file));
        StringBuilder sb = new StringBuilder();
        while (in.hasNextLine()) {
            sb.append(in.nextLine());
        }
        in.close();
        return sb.toString();
    }

    protected void saveFile(String info) throws Exception {
        File dir = new File(URL);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        File file = new File(URL + clazz.getSimpleName() + ".json");
        FileWriter f = new FileWriter(file);
        f.write(info);
        f.flush();
        f.close();
    }

    public void delete(Integer index) throws Exception {
        int indexAjustado = index - 1;
        T[] list = listAll();
        if (indexAjustado < 0 || indexAjustado >= list.length || list[indexAjustado] == null) {
            throw new Exception("Indice fuera de rango o elemento no existente");
        }
        
        T[] newList = (T[]) Array.newInstance(clazz, list.length - 1);
        
        for (int i = 0, j = 0; i < list.length; i++) {
            if (i != indexAjustado) {
                newList[j++] = list[i];
            }
        }
    
        String info;
        try {
            info = g.toJson(newList);
        } catch (Exception e) {
            throw new Exception("Error al convertir a JSON");
        }
        saveFile(info);
    }    

    public void update(Integer index, T object) throws Exception {
        merge(index, object); 
    }
}
