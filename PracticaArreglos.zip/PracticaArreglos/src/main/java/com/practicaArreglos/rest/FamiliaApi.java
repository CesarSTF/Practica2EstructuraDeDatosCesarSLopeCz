package com.practicaArreglos.rest;

import java.util.HashMap;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import com.google.gson.Gson;
import com.practicaArreglos.controller.dao.services.FamiliaServices;
import com.practicaArreglos.controller.dao.services.HistorialCrudServices;
import com.practicaArreglos.controller.excepcion.ListEmptyException;
import com.practicaArreglos.models.Familia;
import com.practicaArreglos.models.TipoDeCrud;

@Path("/familia")
public class FamiliaApi {
    private static final Gson gson = new Gson();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/all")
    public Response getAllFamilias() throws ListEmptyException {
        HashMap<String, Object> res = new HashMap<>();
        FamiliaServices familiaServices = new FamiliaServices();

        try {
            res.put("status", "success");
            res.put("message", "Consulta realizada con exito.");
            res.put("data", familiaServices.listAll());
            return Response.ok(res).build();
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error interno del servidor: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/get/{id}")
    public Response getFamiliaById(@PathParam("id") Integer id) {
        HashMap<String, Object> res = new HashMap<>();
        FamiliaServices familiaServices = new FamiliaServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            Familia familia = familiaServices.getFamiliaByIndex(id);
            if (familia != null) {
                res.put("status", "success");
                res.put("message", "Familia encontrada.");
                res.put("data", familia);
                return Response.ok(res).build();
            } else {
                res.put("status", "error");
                res.put("message", "Familia no encontrada.");
                return Response.status(Status.NOT_FOUND).entity(res).build();
            }
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error interno del servidor: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/create")
    public Response createFamilia(String json) {
        HashMap<String, Object> res = new HashMap<>();
        FamiliaServices familiaServices = new FamiliaServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            Familia familia = gson.fromJson(json, Familia.class);    
            if (familia.getNombreFamilia() == null || familia.getNombreFamilia().isEmpty()) {
                throw new IllegalArgumentException("El nombre de la familia es obligatorio.");
            }
            if (familia.getNroIntegrantes() == null || familia.getNroIntegrantes() < 1) {
                throw new IllegalArgumentException("El numero de integrantes debe ser un numero positivo.");
            }
            familiaServices.setFamilia(familia);
            familiaServices.save();    
            historialCrudServices.registrarHistorial(TipoDeCrud.CREATE, "Familia creada" + familia.toString());        
            res.put("status", "success");
            res.put("message", "Familia creada con exito.");
            res.put("data", familiaServices.toJson());
            return Response.ok(res).build();
        } catch (IllegalArgumentException e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return Response.status(Status.BAD_REQUEST).entity(res).build();
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error al crear la familia: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/delete/{id}")
    public Response deleteFamiliaById(@PathParam("id") Integer id) {
        HashMap<String, Object> res = new HashMap<>();
        FamiliaServices familiaServices = new FamiliaServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            if (familiaServices.deleteFamiliaByIndex(id)) {
                res.put("status", "success");
                res.put("message", "Familia eliminada con exito.");
                historialCrudServices.registrarHistorial(TipoDeCrud.DELETE, "Familia eliminada:" + id);
                return Response.ok(res).build();
            } else {
                res.put("status", "error");
                res.put("message", "No se pudo eliminar la familia.");
                return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
            }
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error interno del servidor: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/update/{id}")
    public Response updateFamilia(@PathParam("id") Integer id, HashMap<String, Object> map) {
        HashMap<String, Object> res = new HashMap<>();
        FamiliaServices familiaServices = new FamiliaServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            if (map.get("nombreFamilia") == null || map.get("nombreFamilia").toString().isEmpty()) {
                throw new IllegalArgumentException("El nombre de la familia es obligatorio.");
            }
            if (map.get("nroIntegrantes") == null || Integer.parseInt(map.get("nroIntegrantes").toString()) < 1) {
                throw new IllegalArgumentException("El numero de integrantes debe ser un numero positivo.");
            }            
            Familia familia = new Familia();
            familia.setIdFamilias(id);
            familia.setNombreFamilia(map.get("nombreFamilia").toString());
            familia.setNroIntegrantes(Integer.parseInt(map.get("nroIntegrantes").toString()));            
            familiaServices.update(id, familia);
            historialCrudServices.registrarHistorial(TipoDeCrud.UPDATE, "Familia actualizada:" + familia.toString());
            res.put("status", "success");
            res.put("message", "Familia actualizada con exito.");
            res.put("data", familiaServices.toJson());
            return Response.ok(res).build();
        } catch (IllegalArgumentException e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return Response.status(Status.BAD_REQUEST).entity(res).build();
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error al actualizar la familia: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }
}
