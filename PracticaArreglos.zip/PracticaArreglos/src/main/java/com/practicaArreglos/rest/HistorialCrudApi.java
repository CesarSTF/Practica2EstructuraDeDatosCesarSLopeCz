package com.practicaArreglos.rest;

import java.util.HashMap;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.practicaArreglos.controller.dao.services.HistorialCrudServices;
import com.practicaArreglos.models.HistorialCrud;
import com.practicaArreglos.controller.excepcion.ListEmptyException;

@Path("/historial")
public class HistorialCrudApi {
    private HistorialCrudServices historialCrudServices = new HistorialCrudServices();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/all")
    public Response getAllHistorialCrud() {
        HashMap<String, Object> map = new HashMap<>();
        try {
            HistorialCrud[] historiales = historialCrudServices.listAll();
            if (historiales.length == 0) {
                throw new ListEmptyException("Error: No hay historial registrado.");
            }
            map.put("msg", "OK");
            map.put("data", historiales);
            return Response.ok(map).build();
        } catch (Exception e) {
            map.put("msg", "Error al obtener la lista de historiales: " + e.getMessage());
            return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(map).build();
        }
    }
}
