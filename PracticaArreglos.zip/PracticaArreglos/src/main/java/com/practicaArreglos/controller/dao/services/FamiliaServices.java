package com.practicaArreglos.controller.dao.services;

import com.practicaArreglos.controller.dao.FamiliaDao;
import com.practicaArreglos.models.Familia;

public class FamiliaServices {
    private FamiliaDao obj;

    public FamiliaServices() {
        this.obj = new FamiliaDao();
    }

    public Boolean save() throws Exception {
        return obj.save();
    }

    public Familia[] listAll() throws Exception {
        return obj.getListAll();
    }

    public Familia getFamilia() {
        return obj.getFamilia();
    }

    public void setFamilia(Familia familia) {
        obj.setFamilia(familia);
    }

    public String toJson() {
        return obj.toJson();
    }

    public String getAllFamiliasToJson() throws Exception {
        return obj.getAllFamiliasJson();
    }

    public Familia getFamiliaByIndex(Integer index) throws Exception {
        return obj.getFamiliaByIndex(index);
    }

    public String getFamiliaJsonByIndex(Integer index) throws Exception {
        return obj.getFamiliaJsonByIndex(index);
    }

    public void update(Integer index, Familia familia) throws Exception {
        obj.update(index, familia);
    }

    public Boolean deleteFamiliaByIndex(Integer index) throws Exception {
        return obj.deleteFamiliaByIndex(index);
    }
}
