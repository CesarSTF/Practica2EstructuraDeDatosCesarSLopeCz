package com.practicaArreglos.rest;

import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.google.gson.Gson;
import com.practicaArreglos.controller.dao.services.GeneradorServices;
import com.practicaArreglos.controller.dao.services.HistorialCrudServices;
import com.practicaArreglos.controller.excepcion.ListEmptyException;
import com.practicaArreglos.models.Generador;
import com.practicaArreglos.models.TipoDeCrud;

@Path("/generador")
public class GeneradorApi {
    private static final Gson gson = new Gson();

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/all")
    public Response getAllGeneradores() throws ListEmptyException{
        HashMap<String, Object> res = new HashMap<>();
        GeneradorServices generadorServices = new GeneradorServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            res.put("status", "success");
            res.put("message", "Consulta realizada con exito.");
            res.put("data", generadorServices.listAll());
            return Response.ok(res).build();            
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error interno del servidor: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/get/{id}")
    public Response getGeneradorById(@PathParam("id") Integer id) {
        HashMap<String, Object> res = new HashMap<>();
        GeneradorServices generadorServices = new GeneradorServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            Generador generador = generadorServices.getGeneradorByIndex(id);
            if (generador != null) {
                res.put("status", "success");
                res.put("message", "Generador encontrado.");
                historialCrudServices.registrarHistorial(TipoDeCrud.READ, "Generador leido:" + generador.toString());
                res.put("data", generador);
                return Response.ok(res).build();
            } else {
                res.put("status", "error");
                res.put("message", "Generador no encontrado.");
                return Response.status(Status.NOT_FOUND).entity(res).build();
            }
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error interno del servidor: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/create")
    public Response createGenerador(String json) {
        HashMap<String, Object> res = new HashMap<>();
        GeneradorServices generadorServices = new GeneradorServices();
        System.out.println("Datos recibidos: " + json);
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            Generador generador = gson.fromJson(json, Generador.class);
            if (generador.getModelo() == null || generador.getModelo().isEmpty()) {
                throw new IllegalArgumentException("El modelo es obligatorio.");
            }
            if (generador.getCosto() < 0) {
                throw new IllegalArgumentException("El costo debe ser un numero positivo.");
            }
            if (generador.getConsumoComustible() < 0) {
                throw new IllegalArgumentException("El consumo de combustible debe ser un numero positivo.");
            }
            if (generador.getenergiaGenerada() < 0) {
                throw new IllegalArgumentException("La energia generada debe ser un numero positivo.");
            }
            if (generador.getUso() == null) {
                throw new IllegalArgumentException("El uso es obligatorio.");
            }
            generadorServices.setGenerador(generador);
            generadorServices.save();
            historialCrudServices.registrarHistorial(TipoDeCrud.CREATE, "Generador creado:" + generador.toString());
            
            res.put("status", "success");
            res.put("message", "Generador creado con exito.");
            res.put("data", generadorServices.toJson());
            return Response.ok(res).build();
        } catch (IllegalArgumentException e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return Response.status(Status.BAD_REQUEST).entity(res).build();
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error al crear el generador: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }

    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/update/{id}")
    public Response updateGenerador(@PathParam("id") Integer id, HashMap<String, Object> map) throws Exception {
        HashMap<String, Object> res = new HashMap<>();
        GeneradorServices generadorServices = new GeneradorServices();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();

        try {
            if (map.get("modelo") == null || map.get("modelo").toString().isEmpty()) {
                throw new IllegalArgumentException("El modelo es obligatorio.");
            }
            if (map.get("costo") == null || Float.parseFloat(map.get("costo").toString()) < 0) {
                throw new IllegalArgumentException("El costo debe ser un numero positivo.");
            }
            if (map.get("consumoComustible") == null || Float.parseFloat(map.get("consumoComustible").toString()) < 0) {
                throw new IllegalArgumentException("El consumo de combustible debe ser un numero positivo.");
            }
            if (map.get("energiaGenerada") == null || Float.parseFloat(map.get("energiaGenerada").toString()) < 0) {
                throw new IllegalArgumentException("La energia generada debe ser un numero positivo.");
            }
            if (map.get("uso") == null || map.get("uso").toString().isEmpty()) {
                throw new IllegalArgumentException("El uso es obligatorio.");
            }

            Generador generador = new Generador();
            generador.setIdGenerador(id);
            generador.setModelo(map.get("modelo").toString());
            generador.setCosto(Float.parseFloat(map.get("costo").toString()));
            generador.setConsumoComustible(Float.parseFloat(map.get("consumoComustible").toString()));
            generador.setenergiaGenerada(Float.parseFloat(map.get("energiaGenerada").toString()));
            generador.setUso(generadorServices.getUso(map.get("uso").toString()));
            generadorServices.update(id, generador);
            historialCrudServices.registrarHistorial(TipoDeCrud.UPDATE, "Generador actualizado: " + generador.toString());
            res.put("status", "success");
            res.put("message", "Generador actualizado con exito.");
            res.put("data", generadorServices.toJson());
            return Response.ok(res).build();
        } catch (IllegalArgumentException e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return Response.status(Status.BAD_REQUEST).entity(res).build();
        } catch (Exception e) {
            res.put("status", "error");
            res.put("message", "Error al actualizar el generador: " + e.getMessage());
            return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/delete/{id}")
    public Response deleteGeneradorById(@PathParam("id") Integer id) {
        HashMap<String, Object> res = new HashMap<>();
        HistorialCrudServices historialCrudServices = new HistorialCrudServices();
        GeneradorServices generadorServices = new GeneradorServices();
    
        try {
            if (id <= 0) {
                throw new IllegalArgumentException("El ID del generador debe ser un numero positivo.");
            }                
            Boolean eliminado = generadorServices.deleteGeneradorByIndex(id);
            if (!eliminado) {
                throw new Exception("No se pudo eliminar el generador con ID: " + id);
            }
            res.put("status", "success");
            res.put("message", "Generador eliminado con exito.");
            historialCrudServices.registrarHistorial(TipoDeCrud.DELETE, "Generador eliminado: " + id);
    
            return Response.ok(res).build();
    
        } catch (IllegalArgumentException e) {
            res.put("status", "error");
            res.put("message", e.getMessage());
            return Response.status(Status.BAD_REQUEST).entity(res).build();
    
        } catch (Exception e) {
            e.printStackTrace();
            res.put("status", "error");
            res.put("message", "Ocurrio un error inesperado: " + e.toString());
        return Response.status(Status.INTERNAL_SERVER_ERROR).entity(res).build();
        }
    }        
}
